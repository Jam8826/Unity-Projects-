---
name: Feature request
about: Suggest an idea for this project

---

**Is your feature request related to a problem? Please describe.**

**Describe the solution you'd like to see**

**Describe alternatives you've considered**

**Additional context**
