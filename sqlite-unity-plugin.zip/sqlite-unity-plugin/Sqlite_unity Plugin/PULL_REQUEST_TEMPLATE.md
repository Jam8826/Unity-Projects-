Pull requests must be tested on Windows, iOS and Android platforms.
